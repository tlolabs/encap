# Transcription engine dependencies

WhisperKit / Argmax OSS Swift: Copyright 2024 Argmax, Inc. MIT License.
The local-only tokenizer adapter's word-splitting algorithm is adapted from
WhisperKit's `WhisperTokenizerWrapper` at revision
`9f99b5cb6a907730543823ad271b82532782a899`.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

FluidAudio is Apache-2.0. MLX Audio Swift and MLX Swift are MIT.
These SDK licenses are separate from the model-weight licenses recorded in
the verified model catalog. Preserve upstream licenses and notices when
redistributing these libraries or weights.
